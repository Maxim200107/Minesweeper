﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Windows.Threading;

namespace Minesweeper
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private MinesweeperModel minesweeper;
        class MinesweeperModel : INotifyPropertyChanged
        {
            public class CellInfo
            {
                public bool IsMine { get; set; }
                public bool Closed { get; set; }
                public bool Selected { get; set; }
                public bool Exploded { get; set; }
                public int MineCount { get; set; }

                public CellInfo()
                {
                    IsMine = false;
                    Closed = true;
                    Selected = false;
                    Exploded = false;
                    MineCount = 0;
                }
            }
            private int _columnCount;
            public int ColumnCount => _columnCount;

            private int _rowCount;
            public int RowCount => _rowCount;

            private int _mineCount;
            public int MineCount => _mineCount;

            private int _mineLeft;
            public int MineLeft { get { return _mineLeft; } 
                set
                {
                    if (_mineLeft != value)
                    {
                        _mineLeft = value;
                        OnPropertyChanged("MineLeft");
                    }
                } 
            }

            private bool _exploded;
            public bool Exploded => _exploded;

            public bool Won
            {
                get
                {
                    if (!_exploded)
                    {
                        int openCnt = 0;
                        for (int column = 0; column < _columnCount; column++)
                            for (int row = 0; row < _rowCount; row++)
                            {
                                if (!_mineField[column, row].Closed)
                                    openCnt++;
                            }
                        if (openCnt + _mineCount == _columnCount * _rowCount)
                        {
                            MineLeft = 0;
                            return true;
                        }
                        else
                            return false;
                    }
                    else
                        return false;
                }
            }
            
            public bool GameOwer { 
                get 
                {
                    if (Won || Exploded)
                    {
                        _timer.Stop();
                        return true;
                    }
                    else
                        return false;
                } 
            }

            private CellInfo[,] _mineField;
            public CellInfo[,] MineField => _mineField;

            private readonly DispatcherTimer _timer;
            private int _gameTime;
            public int GameTime
            {
                get { return _gameTime; }
                set
                {
                    if (_gameTime != value)
                    {
                        _gameTime = value;
                        OnPropertyChanged("GameTime");
                    }
                }
            }

            public event PropertyChangedEventHandler? PropertyChanged;

            public MinesweeperModel()
            {
                _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
                _timer.Tick += timer_Tick;

                _mineField = new CellInfo[0, 0];
                SetField(9, 9, 10);
            }
            public void SetField(int columnCount, int rowCount, int mineCount)
            {
                _timer.Stop();
                _columnCount = columnCount;
                _rowCount = rowCount;
                _mineCount = mineCount;
                MineLeft = mineCount;
                _exploded = false;
                _mineField = new CellInfo[columnCount, rowCount];
                for (int column = 0; column < columnCount; column++)
                    for (int row = 0; row < rowCount; row++)
                        _mineField[column, row] = new CellInfo();
                Random rnd = new Random();
                for (int mine = 0; mine < mineCount; mine++)
                {
                    int column = rnd.Next(columnCount);
                    int row = rnd.Next(rowCount);
                    while (_mineField[column, row].IsMine)
                    {
                        column = rnd.Next(columnCount);
                        row = rnd.Next(rowCount);
                    }
                    _mineField[column, row].IsMine = true;
                }
                for (int column = 0; column < columnCount; column++)
                    for (int row = 0; row < rowCount; row++)
                        if (!_mineField[column, row].IsMine)
                            for (int dColumn = column - 1; dColumn <= column + 1; dColumn++)
                                for (int dRow = row - 1; dRow <= row + 1; dRow++)
                                    if (dColumn >= 0 && dColumn < columnCount && dRow >= 0 && dRow < rowCount && _mineField[dColumn, dRow].IsMine)
                                        _mineField[column, row].MineCount++;
                GameTime = 0;
            }
            public void SetSelected(int column, int row)
            {
                if (GameOwer)
                    return;
                if (_gameTime == 0)
                    _timer.Start();
                if (_mineField[column, row].Closed)
                {
                    _mineField[column, row].Selected = !_mineField[column, row].Selected;
                    if (_mineField[column, row].Selected)
                        MineLeft--;
                    else
                        MineLeft++;
                }
            }
            public void OpenField(int column, int row)
            {
                if (GameOwer)
                    return;
                if (_gameTime == 0)
                    _timer.Start();
                if (_mineField[column, row].Closed && !_mineField[column, row].Selected)
                {
                    _mineField[column, row].Closed = false;
                    if (_mineField[column, row].IsMine)
                    {
                        _mineField[column, row].Exploded = true;
                        _exploded = true;
                    }
                    else if (_mineField[column, row].MineCount == 0)
                    {                        
                        for (int dColumn = column - 1; dColumn <= column + 1; dColumn++)
                            for (int dRow = row - 1; dRow <= row + 1; dRow++)
                                if (dColumn >= 0 && dColumn < _columnCount && dRow >= 0 && dRow < _rowCount && _mineField[dColumn, dRow].Closed)
                                    OpenField(dColumn, dRow);
                    }
                }
            }
            protected void OnPropertyChanged(string name)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
            }
            private void timer_Tick(object? sender, EventArgs e)
            {
                GameTime += 1;
            }
        }
        public MainWindow()
        {
            minesweeper = new MinesweeperModel();

            InitializeComponent();

            DataContext = minesweeper;

            InitField();
            DrawField();
        }
        private void InitField()
        {
            int cellSize = (int) (window.MinWidth / minesweeper.ColumnCount) + 1;
            if (cellSize < 30)
                cellSize = 30;
            MineFieldGrid.Children.Clear();
            MineFieldGrid.ColumnDefinitions.Clear();
            MineFieldGrid.RowDefinitions.Clear();
            for (int column = 0; column < minesweeper.ColumnCount; column++)
            {
                var cd = new ColumnDefinition();
                cd.MinWidth = cellSize;
                cd.MaxWidth = cellSize;
                MineFieldGrid.ColumnDefinitions.Add(cd);
            }
            for (int row = 0; row < minesweeper.RowCount; row++)
            {
                var rd = new RowDefinition();
                rd.MinHeight = cellSize;
                rd.MaxHeight = cellSize;
                MineFieldGrid.RowDefinitions.Add(rd);
            }
            for (int column = 0; column < minesweeper.ColumnCount; column++)
                for (int row = 0; row < minesweeper.RowCount; row++)
                {
                    Button btn = new Button();
                    btn.Name = "Button_" + column.ToString() + "_" + row.ToString();
                    btn.Click += ButtonItem_Click;
                    btn.MouseDown += ButtonItem_MouseDown;
                    btn.Content = "";
                    Grid.SetColumn(btn, column);
                    Grid.SetRow(btn, row);
                    MineFieldGrid.Children.Add(btn);
                }
        }
        private void DrawField()
        {
            bool win = minesweeper.Won;
            foreach (Button btn in MineFieldGrid.Children.OfType<Button>().ToList())
            {
                int column = Grid.GetColumn(btn);
                int row = Grid.GetRow(btn);
                btn.Content = "";
                btn.Background = new SolidColorBrush(Colors.LightGray);
                if (minesweeper.Exploded)
                {
                    btn.Background = new SolidColorBrush(Colors.White);
                    if (minesweeper.MineField[column, row].IsMine)
                    {
                        if (minesweeper.MineField[column, row].Exploded)
                            btn.Background = new SolidColorBrush(Colors.Red);
                        else if (minesweeper.MineField[column, row].Selected)
                            btn.Background = new SolidColorBrush(Colors.Green);
                        else
                            btn.Background = new SolidColorBrush(Colors.Blue);
                    }
                    else if (minesweeper.MineField[column, row].Selected && !minesweeper.MineField[column, row].IsMine)
                    {
                        btn.Content = "X";
                        btn.Background = new SolidColorBrush(Colors.Aqua);
                    }
                    else if (minesweeper.MineField[column, row].MineCount != 0)
                        btn.Content = minesweeper.MineField[column, row].MineCount.ToString();
                }
                else if (!minesweeper.MineField[column, row].Closed)
                {
                    btn.Background = new SolidColorBrush(Colors.White);
                    if (minesweeper.MineField[column, row].MineCount != 0)
                        btn.Content = minesweeper.MineField[column, row].MineCount.ToString();
                }
                else if (minesweeper.MineField[column, row].Selected || win)
                    btn.Background = new SolidColorBrush(Colors.Green);
            }
            if (minesweeper.GameOwer)
            {
                if (minesweeper.Won)
                    MessageBox.Show("You won!", "Miewsweeoer");
                else
                    MessageBox.Show("You lose!", "Miewsweeoer");
            }
        }
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void ButtonAddName_Click(object sender, RoutedEventArgs e)
        {
            int _columnCount = minesweeper.ColumnCount;
            int _rowCount = minesweeper.RowCount;
            int columnCount = Convert.ToInt16(ColumnsTextBox.Text);
            int rowCount = Convert.ToInt16(RowsTextBox.Text);
            int mineCount = Convert.ToInt16(MinesTextBox.Text);
            minesweeper.SetField(columnCount, rowCount, mineCount);
            if (_columnCount != columnCount || _rowCount != rowCount)
                InitField();
            DrawField();
        }
        private void ButtonItem_Click(object sender, RoutedEventArgs e)
        {
            if (minesweeper.GameOwer)
                return;
            Button btn = (Button)sender;
            int column = Grid.GetColumn(btn);
            int row = Grid.GetRow(btn);
            minesweeper.OpenField(column, row);
            DrawField();
        }
        private void ButtonItem_MouseDown(object sender, MouseEventArgs e)
        {
            if (!minesweeper.GameOwer && e.RightButton == MouseButtonState.Pressed)
            {
                Button btn = (Button)sender;
                int column = Grid.GetColumn(btn);
                int row = Grid.GetRow(btn);
                minesweeper.SetSelected(column, row);
                DrawField();
            }
        }
    }
}
